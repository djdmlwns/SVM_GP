example.py has a code to run for a example with Hosaki 2D benchmark function.

In core folder, the main algorithm for the active sampling is defined as a class.
In auxil folder, auxiliary functions that are needed for the main algorithm is included.
In plotting folder, all codes for plotting are included.
In data folder, it is made to write/read text file when we use simulation.

